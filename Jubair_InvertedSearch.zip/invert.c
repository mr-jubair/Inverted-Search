#include "invert.h"

/* Validate all input files before creating the database */
int file_validation(char *argv[], file_node **head)
{
    int i = 1;

    /* Check every file passed through the command line */
    while(argv[i] != NULL)
    {
        /* Verify whether the file has a .txt extension */
        if(check_txt_file(argv[i]) == FAILURE)
        {
            printf(RED"%s Given file is not a txt file\n"RESET,argv[i]);
            i++;
            continue;
        }

        /* Skip the file if it is empty */
        if(check_empty_file(argv[i]) == FAILURE)
        {
            printf(RED"%s Given file is empty\n"RESET,argv[i]);
            i++;
            continue;
        }

        /* Ignore duplicate files to avoid repeated indexing */
        if(check_duplicate(*head,argv[i]) == SUCCESS)
        {
            printf(YELLOW"%s Given file is duplicate\n"RESET,argv[i]);
            i++;
            continue;
        }

        /* Store the validated file in the linked list */
        insert_last(head,argv[i]);

        printf(GREEN"%s Given file validated successfully\n"RESET,argv[i]);

        i++;
    }

    return SUCCESS;
}

/* Verify that the file has a valid .txt extension */
int check_txt_file(char *filename)
{
    char *ptr = strrchr(filename,'.');

    if(ptr != NULL && strcmp(ptr,".txt") == 0)
        return SUCCESS;

    return FAILURE;
}

/* Check whether the input file contains any data */
int check_empty_file(char *filename)
{
    FILE *fp = fopen(filename,"r");

    if(fp == NULL)
        return FAILURE;

    fseek(fp,0,SEEK_END);

    if(ftell(fp) == 0)
    {
        fclose(fp);
        return FAILURE;
    }

    fclose(fp);
    return SUCCESS;
}

/* Check if the file is already present in the linked list */
int check_duplicate(file_node *head,char *filename)
{
    while(head)
    {
        if(strcmp(head->file_name,filename) == 0)
            return SUCCESS;

        head = head->link;
    }

    return FAILURE;
}

/* Add a validated file to the end of the linked list */
int insert_last(file_node **head,char *filename)
{
    file_node *new = malloc(sizeof(file_node));

    if(new == NULL)
        return FAILURE;

    strcpy(new->file_name,filename);
    new->link = NULL;

    /* Insert the first node if the list is empty */
    if(*head == NULL)
    {
        *head = new;
        return SUCCESS;
    }

    /* Move to the last node of the list */
    file_node *temp = *head;

    while(temp->link)
        temp = temp->link;

    /* Link the new file node at the end */
    temp->link = new;

    return SUCCESS;
}

/* Display all validated input files */
void print_list(file_node *head)
{
    printf(BLUE"\nValidated Files\n"RESET);

    /* Traverse and print every file name */
    while(head)
    {
        printf("%s -> ",head->file_name);
        head = head->link;
    }

    printf("NULL\n");
}