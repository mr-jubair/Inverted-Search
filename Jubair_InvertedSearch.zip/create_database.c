#include "invert.h"

/* Helper functions used to build the database */
static int get_index(char *word);
static int insert_main_node(hash_t arr[], char *word, char *filename, int index);
static int update_main_node(main_node_t *head, char *word, char *filename);

int create_database(file_node *head, hash_t arr[])
{
    FILE *fp;
    char word[25];
    int index;

    /* Start with the first validated file */
    file_node *temp = head;

    /* Process every file in the linked list */
    while(temp != NULL)
    {
        /* Open the current file in read mode */
        fp = fopen(temp->file_name,"r");

        /* Skip the file if it cannot be opened */
        if(fp == NULL)
        {
            printf(RED "Unable to open %s\n" RESET,temp->file_name);
            temp = temp->link;
            continue;
        }

        /* Read one word at a time from the file */
        while(fscanf(fp,"%24s",word) == 1)
        {
            /* Calculate the hash index for the word */
            index = get_index(word);

            /* Insert a new entry if the bucket is empty */
            if(arr[index].link == NULL)
            {
                if(insert_main_node(arr, word, temp->file_name, index) == FAILURE)
                {
                    fclose(fp);
                    return FAILURE;
                }
            }
            /* Update the existing database entry */
            else
            {
                if(update_main_node(arr[index].link, word, temp->file_name) == FAILURE)
                {
                    fclose(fp);
                    return FAILURE;
                }
            }
        }

        /* Close the current file */
        fclose(fp);

        /* Continue with the next file */
        temp = temp->link;
    }

    return SUCCESS;
}

/* Generate the hash index using the first character */
static int get_index(char *word)
{
    char ch = word[0];

    /* Index for lowercase letters */
    if(ch >= 'a' && ch <= 'z')
        return ch - 'a';

    /* Index for uppercase letters */
    else if(ch >= 'A' && ch <= 'Z')
        return ch - 'A';

    /* Store all other characters in the last bucket */
    return 26;
}

/* Create a new word entry in the hash table */
static int insert_main_node(hash_t arr[], char *word, char *filename, int index)
{
    /* Allocate memory for the main node */
    main_node_t *new_main = malloc(sizeof(main_node_t));

    if(new_main == NULL)
        return FAILURE;

    /* Allocate memory for the sub node */
    sub_node_t *new_sub = malloc(sizeof(sub_node_t));

    if(new_sub == NULL)
    {
        free(new_main);
        return FAILURE;
    }

    /* Initialize the main node */
    strcpy(new_main->word,word);
    new_main->file_count = 1;
    new_main->main_link = NULL;
    new_main->sub_link = new_sub;

    /* Initialize the first sub node */
    strcpy(new_sub->file_name,filename);
    new_sub->word_count = 1;
    new_sub->sub_link = NULL;

    /* Attach the new node to the hash table */
    arr[index].link = new_main;

    return SUCCESS;
}

/* Update an existing word or insert a new one */
static int update_main_node(main_node_t *head, char *word, char *filename)
{
    main_node_t *temp = head;
    main_node_t *prev = NULL;

    /* Search for the word in the main node list */
    while(temp != NULL)
    {
        /* Word found in the database */
        if(strcmp(temp->word, word) == 0)
        {
            sub_node_t *sub = temp->sub_link;
            sub_node_t *sub_prev = NULL;

            /* Search for the file in the sub node list */
            while(sub != NULL)
            {
                /* Increase the count if the file already exists */
                if(strcmp(sub->file_name, filename) == 0)
                {
                    sub->word_count++;
                    return SUCCESS;
                }

                sub_prev = sub;
                sub = sub->sub_link;
            }

            /* Create a new sub node for a different file */
            sub_node_t *new_sub = malloc(sizeof(sub_node_t));

            if(new_sub == NULL)
                return FAILURE;

            strcpy(new_sub->file_name, filename);
            new_sub->word_count = 1;
            new_sub->sub_link = NULL;

            /* Attach the new file to the existing word */
            sub_prev->sub_link = new_sub;

            /* Increase the file count */
            temp->file_count++;

            return SUCCESS;
        }

        prev = temp;
        temp = temp->main_link;
    }

    /* Create a new main node if the word is not found */
    main_node_t *new_main = malloc(sizeof(main_node_t));

    if(new_main == NULL)
        return FAILURE;

    /* Create the first sub node for the new word */
    sub_node_t *new_sub = malloc(sizeof(sub_node_t));

    if(new_sub == NULL)
    {
        free(new_main);
        return FAILURE;
    }

    strcpy(new_main->word, word);
    new_main->file_count = 1;
    new_main->sub_link = new_sub;
    new_main->main_link = NULL;

    strcpy(new_sub->file_name, filename);
    new_sub->word_count = 1;
    new_sub->sub_link = NULL;

    /* Link the new word at the end of the list */
    prev->main_link = new_main;

    return SUCCESS;
}