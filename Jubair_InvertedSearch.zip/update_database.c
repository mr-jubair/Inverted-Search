#include "invert.h"

/* Helper Prototypes */
static main_node_t *create_main_node(char *word, int file_count);
static sub_node_t *create_sub_node(char *filename, int word_count);

int update_database(hash_t arr[], file_node **head)
{
    char filename[25];
    FILE *fp;

    int index;
    int file_count;
    char word[25];

    /* Read filename */
    printf("\nEnter the filename : ");
    scanf("%24s", filename);

    /* Validate extension */
    if(check_txt_file(filename) == FAILURE)
    {
        printf(RED "\nERROR : Invalid file extension\n" RESET);
        return FAILURE;
    }

    /* Check file exists */
    fp = fopen(filename, "r");

    if(fp == NULL)
    {
        printf(RED "\nERROR : File not found\n" RESET);
        return FAILURE;
    }

    /* Check empty file */
    fseek(fp, 0, SEEK_END);

    if(ftell(fp) == 0)
    {
        printf(RED "\nERROR : Empty file\n" RESET);
        fclose(fp);
        return FAILURE;
    }

    rewind(fp);

    /* Database already created? */
    for(int i = 0; i < HASH_SIZE; i++)
    {
        if(arr[i].link != NULL)
        {
            printf(YELLOW "\nINFO : Database is already created\n" RESET);
            fclose(fp);
            return FAILURE;
        }
    }

    printf(GREEN "\nReading database file...\n\n" RESET);

    char file_name[25];
    int word_count;

    sub_node_t *sub;
    sub_node_t *prev;
    
    /* Read one record at a time */
    while(fscanf(fp, "#%d;%24[^;];%d;", &index, word, &file_count) == 3)
    {
        printf("Reading : Index=%d Word=%s FileCount=%d\n", index, word, file_count);
        /* Create Main Node */
        main_node_t *main_new = create_main_node(word, file_count);

        if(main_new == NULL)
        {
            fclose(fp);
            return FAILURE;
        }

        prev = NULL;

        /* Read all Sub Nodes */
        for(int i = 0; i < file_count; i++)
        {
            if(fscanf(fp,"%24[^;];%d;", file_name, &word_count) != 2)
            {
                fclose(fp);
                return FAILURE;
            }

            sub = create_sub_node(file_name, word_count);

            if(sub == NULL)
            {
                fclose(fp);
                return FAILURE;
            }

            if(prev == NULL)
            {
                main_new->sub_link = sub;
            }
            else
            {
                prev->sub_link = sub;
            }

            prev = sub;
            file_node *temp = *head;
            file_node *prev_file = NULL;

            while(temp != NULL)
            {
                if(strcmp(file_name, temp->file_name) == 0)
                {
                    if(prev_file == NULL)
                    {
                        *head = temp->link;
                    }
                    else
                    {
                        prev_file->link = temp->link;
                    }

                    free(temp);
                    break;
                }
                prev_file = temp;
                temp = temp->link;
            }
        }

        /* Skip ending '#' */
        char ch = fgetc(fp);

        if(ch != '#')
        {
            printf("Expected # but got %c\n", ch);
            fclose(fp);
            return FAILURE;
        }

        /* Skip newline after # */
        while((ch = fgetc(fp)) == '\n' || ch == '\r');

        /* Put back the first character of next record (#) */
        if(ch != EOF)
        {
            fseek(fp, -1, SEEK_CUR);
        }

        /* Connect Main Node to Hash Table */
        if(arr[index].link == NULL)
        {
            arr[index].link = main_new;
        }
        else
        {
            main_node_t *temp = arr[index].link;

            while(temp->main_link != NULL)
            {
                temp = temp->main_link;
            }

            temp->main_link = main_new;
        }
    }

    printf(GREEN "\nINFO : Database updated successfully\n" RESET);

    fclose(fp);

    return SUCCESS;
}

static main_node_t *create_main_node(char *word, int file_count)
{
    main_node_t *new = malloc(sizeof(main_node_t));

    if(new == NULL)
        return NULL;

    strcpy(new->word, word);

    new->file_count = file_count;

    new->sub_link = NULL;

    new->main_link = NULL;

    return new;
}

static sub_node_t *create_sub_node(char *filename, int word_count)
{
    sub_node_t *new = malloc(sizeof(sub_node_t));

    if(new == NULL)
        return NULL;

    strcpy(new->file_name, filename);

    new->word_count = word_count;

    new->sub_link = NULL;

    return new;
}