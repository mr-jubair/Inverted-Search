#include "invert.h"

/* Helper function to calculate the hash index */
static int get_index(char *word);

/* Search for a word in the inverted database */
void search_database(hash_t arr[])
{
    char word[25];
    int index;

    /* Read the word to be searched */
    printf("\nEnter the word to search : ");

    if(scanf("%24s", word) != 1)
    {
        printf(RED "\nERROR : Invalid input.\n" RESET);
        return;
    }

    /* Calculate the hash index of the given word */
    index = get_index(word);

    /* Check whether the corresponding hash index contains any data */
    if(arr[index].link == NULL)
    {
        printf(RED "\nWord %s is not present in the database.\n" RESET, word);
        return;
    }

    main_node_t *main_temp = arr[index].link;

    /* Search for the word in the main node list */
    while(main_temp != NULL)
    {
        /* Display the search result if the word is found */
        if(strcmp(main_temp->word, word) == 0)
        {
            printf(BOLD CYAN);
            printf("\n==========================================================\n");
            printf("%35s\n", "SEARCH RESULT");
            printf("==========================================================\n");
            printf(RESET);

            printf(GREEN "SUCCESS : Word Found\n\n" RESET);

            printf("Word       : %s\n", word);
            printf("File Count : %d\n\n", main_temp->file_count);

            printf("%-25s %-10s\n", "FILE NAME", "WORD COUNT");
            printf("----------------------------------------------------------\n");

            sub_node_t *sub_temp = main_temp->sub_link;

            /* Display every file containing the searched word */
            while(sub_temp != NULL)
            {
                printf("%-25s %-10d\n",
                       sub_temp->file_name,
                       sub_temp->word_count);

                sub_temp = sub_temp->sub_link;
            }

            printf("==========================================================\n");
            return;
        }

        /* Move to the next word in the same hash index */
        main_temp = main_temp->main_link;
    }

    /* Display a message if the word is not found */
    printf(RED "\nERROR : '%s' is not present in the database.\n" RESET, word);
}

/* Generate the hash index using the first character of the word */
static int get_index(char *word)
{
    char ch = word[0];

    /* Return index for lowercase letters */
    if(ch >= 'a' && ch <= 'z')
        return ch - 'a';

    /* Return index for uppercase letters */
    else if(ch >= 'A' && ch <= 'Z')
        return ch - 'A';

    /* Store special characters in the last hash bucket */
    return 26;
}