/*
Name : N.S.Mahammed Jubair
Date : 09/07/2026

Project Description:

The Inverted Search project is a command-line application implemented in C that efficiently searches for words across multiple text
files by creating an indexed database. Instead of scanning every file whenever a search is performed, the application builds an
Inverted Index using a Hash Table, where each unique word is associated with the files in which it appears along with its frequency
of occurrence.

The project combines Hash Tables, Linked Lists, dynamic memory allocation and file handling to provide fast word retrieval while
efficiently organizing large amounts of textual data. By indexing the words only once, the application significantly reduces the
search time compared to traditional sequential searching methods.

The project includes the following functionalities:

1. Create Database
   - Reads multiple text files provided through command-line arguments.
   - Extracts every word from each file and stores it in an indexed database.
   - Uses hashing to organize words efficiently for faster searching.

2. Display Database
   - Displays the complete database in a well-structured tabular format.
   - Shows the index value, word, file count, file names and word frequency.
   - Traverses both Main Nodes and Sub Nodes to present the stored information.

3. Search Database
   - Searches for a given word using its hash index.
   - Displays the files containing the searched word.
   - Shows the number of occurrences of the word in each file.

4. Update Database
   - Restores a previously saved database from a text file.
   - Reconstructs the Hash Table and Linked Lists dynamically.
   - Preserves all indexed data without rebuilding the database manually.

5. Save Database
   - Stores the complete database into a text file.
   - Saves all index values, words, file information and word counts.
   - Allows the database to be reused in future executions.

6. Input Validation
   - Validates command-line arguments before processing.
   - Checks file extensions, file existence and empty files.
   - Prevents duplicate file entries and invalid user inputs.

7. Memory Management
   - Dynamically allocates memory for Main Nodes and Sub Nodes.
   - Uses linked list operations to maintain the database efficiently.
   - Frees all allocated memory before program termination to avoid memory leaks.

Overall, this project demonstrates the practical implementation of Hash Tables, Linked Lists, dynamic memory management,
file handling, string processing and modular programming. It provides hands-on experience in designing an efficient text indexing
system capable of performing fast and organized searches across multiple text files.

***********************************************************************************************************************************************
*/

#include "invert.h"

int main(int argc, char *argv[])
{
    /* Ensure at least one input file is provided */
    if (argc < 2)
    {
        printf(RED "Error: Pass atleast one valid .txt file through command line.\n" RESET);
        return FAILURE;
    }

    /* Head pointer for the validated file list */
    file_node *head = NULL;

    /* Hash table used to store the inverted index */
    hash_t arr[HASH_SIZE];

    /* Initialize every hash table entry */
    for (int i = 0; i < HASH_SIZE; i++)
    {
        arr[i].index = i;
        arr[i].link = NULL;
    }

    /* Validate all input files */
    file_validation(argv, &head);

    /* Exit if no valid files are available */
    if (head == NULL)
    {
        printf(RED "\nNo valid files found.\n" RESET);
        return FAILURE;
    }

    /* Display the project title */
    printf(BOLD CYAN);
    printf("\n============================================================\n");
    printf("          INVERTED SEARCH USING HASH TABLE\n");
    printf("============================================================\n");
    printf(RESET);

    /* Display the list of validated files */
    printf(BOLD GREEN "\nValidated File List\n");
    printf("-------------------\n" RESET);
    print_list(head);

    int choice;
    int create_flag = 0, update_flag = 0;

    /* Display the menu until the user exits */
    do
    {
        /* Print the main menu */
        printf(BOLD BLUE);
        printf("\n==================================================\n");
        printf("              INVERTED SEARCH MENU\n");
        printf("==================================================\n");
        printf(RESET);

        printf(YELLOW "1." RESET " Create Database\n");
        printf(YELLOW "2." RESET " Display Database\n");
        printf(YELLOW "3." RESET " Search Database\n");
        printf(YELLOW "4." RESET " Update Database\n");
        printf(YELLOW "5." RESET " Save Database\n");
        printf(YELLOW "6." RESET " Exit\n");

        /* Read the user's menu choice */
        printf(BOLD MAGENTA "\nEnter your choice : " RESET);

        if(scanf("%d",&choice) != 1)
        {
            /* Clear invalid input from the buffer */
            while(getchar() != '\n');

            printf(RED "\nERROR : Invalid input.\n" RESET);

            continue;
        }

        switch (choice)
        {
            case 1:

                /* Create the database only once */
                if (create_flag == 1)
                {
                    printf(YELLOW "\nINFO : Database is already created.\n" RESET);
                }
                else
                {
                    if (create_database(head, arr) == SUCCESS)
                    {
                        printf(GREEN "\nINFO : Database created successfully.\n" RESET);
                        create_flag = 1;
                    }
                    else
                    {
                        printf(RED "\nERROR : Database creation failed.\n" RESET);
                    }
                }
                break;

            case 2:

                /* Display the database if it exists */
                if(create_flag == 0 && update_flag == 0)
                {
                    printf(YELLOW "\nWARNING : Database is Empty. Create the Database first!\n" RESET);
                }
                else
                {
                    display_database(arr);
                }
                break;

            case 3:

                /* Search only after the database is created */
                if(create_flag == 0 && update_flag == 0)
                {
                    printf(YELLOW "\nWARNING : Database is Empty. Create the Database first!\n" RESET);
                }
                else
                {
                    search_database(arr);
                }
                break;

            case 4:

                /* Update the database if it is not already created */
                if(create_flag == 1)
                {
                    printf(YELLOW "\nWARNING : Database is already created.\n" RESET);
                }
                else
                {
                    if(update_database(arr, &head) == SUCCESS)
                    {
                        update_flag = 1;
                    }

                    /* Display the updated file list */
                    print_list(head);
                }
                break;

            case 5:

                /* Save the database after successful creation */
                if(create_flag == 0 && update_flag == 0)
                {
                    printf(YELLOW "\nWARNING : Database is Empty. Create the Database first!\n" RESET);
                }
                else
                {
                    save_database(arr);
                }
                break;

            case 6:

                /* Display the exit message */
                printf(BOLD GREEN);
                printf("\n==================================================\n");
                printf("      THANK YOU FOR USING INVERTED SEARCH\n");
                printf("==================================================\n");
                printf(RESET);
                break;

            default:

                /* Handle invalid menu choices */
                printf(RED "\nERROR : Please enter a valid option (1-6).\n" RESET);
        }

    } while (choice != 6);

    /* Release all allocated memory before exiting */
    free_database(arr);
    free_file_list(head);

    return SUCCESS;
}