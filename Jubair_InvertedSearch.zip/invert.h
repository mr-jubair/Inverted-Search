#ifndef INV_H
#define INV_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define RESET   "\x1b[0m"
#define RED     "\x1b[31m"
#define GREEN   "\x1b[32m"
#define YELLOW  "\x1b[33m"
#define BLUE    "\x1b[34m"
#define MAGENTA "\x1b[35m"
#define CYAN    "\x1b[36m"
#define BOLD    "\x1b[1m"

// Status Codes 
#define SUCCESS 1
#define FAILURE 0

// Hash Table Size 
#define HASH_SIZE 27

/* File Linked List */
typedef struct node
{
    char file_name[25];
    struct node *link;

}file_node;

/* Sub Node */
typedef struct subnode
{
    char file_name[25];
    int word_count;
    struct subnode *sub_link;

}sub_node_t;

/* Main Node */
typedef struct mainnode
{
    int file_count;
    char word[25];

    sub_node_t *sub_link;
    struct mainnode *main_link;

}main_node_t;

/* Hash Table */
typedef struct hashtable
{
    int index;
    main_node_t *link;

}hash_t;

/* Function Prototypes */

/* File Validation */
int file_validation(char *argv[], file_node **head);

/* Check Extension */
int check_txt_file(char *filename);

/* Check Empty File */
int check_empty_file(char *filename);

/* Check Duplicate File */
int check_duplicate(file_node *head,char *filename);

/* Insert File */
int insert_last(file_node **head,char *filename);

/* Print File List */
void print_list(file_node *head);

/* Database Operations */
int create_database(file_node *head, hash_t arr[]);
void display_database(hash_t arr[]);
void search_database(hash_t arr[]);
int update_database(hash_t arr[], file_node **head);
int save_database(hash_t arr[]);

/* Memory Deallocation */
void free_database(hash_t arr[]);
void free_file_list(file_node *head);

#endif