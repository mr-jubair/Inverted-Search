#include "invert.h"

/* Save the current database into a text file */
int save_database(hash_t arr[])
{
    char filename[25];
    FILE *fp;

    /* Read the output file name from the user */
    printf("\nEnter the file name to save database : ");
    scanf("%24s", filename);

    /* Verify that the file has a valid .txt extension */
    if(check_txt_file(filename) == FAILURE)
    {
        printf(RED "\nERROR : Invalid file extension\n" RESET);
        return FAILURE;
    }

    /* Create the output file for storing the database */
    fp = fopen(filename, "w");

    if(fp == NULL)
    {
        printf(RED "\nERROR : Unable to create file\n" RESET);
        return FAILURE;
    }

    /* Traverse every hash table index */
    for(int i = 0; i < HASH_SIZE; i++)
    {
        /* Skip empty hash table entries */
        if(arr[i].link != NULL)
        {
            main_node_t *mtemp = arr[i].link;

            /* Write every main node into the file */
            while(mtemp != NULL)
            {
                fprintf(fp, "#%d;%s;%d;", i, mtemp->word, mtemp->file_count);

                sub_node_t *stemp = mtemp->sub_link;

                /* Write all associated file details */
                while(stemp != NULL)
                {
                    fprintf(fp, "%s;%d;", stemp->file_name, stemp->word_count);

                    stemp = stemp->sub_link;
                }

                /* Mark the end of the current record */
                fprintf(fp, "#\n");

                mtemp = mtemp->main_link;
            }
        }
    }

    /* Close the output file */
    fclose(fp);

    /* Notify the user after successful saving */
    printf(GREEN "\nINFO : Database is saved successfully.\n" RESET);

    return SUCCESS;
}