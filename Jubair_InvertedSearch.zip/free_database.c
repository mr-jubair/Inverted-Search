#include "invert.h"

/* Release all dynamically allocated database nodes */
void free_database(hash_t arr[])
{
    /* Traverse every hash table index */
    for(int i = 0; i < HASH_SIZE; i++)
    {
        main_node_t *main = arr[i].link;

        /* Free all main nodes at the current index */
        while(main != NULL)
        {
            sub_node_t *sub = main->sub_link;

            /* Free every sub node linked to the current word */
            while(sub != NULL)
            {
                sub_node_t *temp_sub = sub;
                sub = sub->sub_link;
                free(temp_sub);
            }

            /* Free the current main node */
            main_node_t *temp_main = main;
            main = main->main_link;
            free(temp_main);
        }

        /* Reset the hash table entry */
        arr[i].link = NULL;
    }
}

/* Release the linked list of validated files */
void free_file_list(file_node *head)
{
    /* Free every file node one by one */
    while(head != NULL)
    {
        file_node *temp = head;
        head = head->link;
        free(temp);
    }
}