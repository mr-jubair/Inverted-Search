#include "invert.h"

void display_database(hash_t arr[])
{
    int i = 0;
    int flag = 0;

    main_node_t *main_temp;
    sub_node_t *sub_temp;

    /* Print the database heading */
    printf("\n");

    printf(BOLD CYAN);
    printf("============================================================================================================\n");
    printf("%68s\n", "INVERTED SEARCH DATABASE");
    printf("============================================================================================================\n");
    printf(RESET);

    /* Display the table column headings */
    printf(BOLD "%-8s %-20s %-15s %-25s %-12s\n", "INDEX", "WORD", "FILE COUNT", "FILE NAME", "WORD COUNT" RESET);

    printf("------------------------------------------------------------------------------------------------------------\n");

    /* Traverse every index of the hash table */
    for(i = 0; i < HASH_SIZE; i++)
    {
        /* Skip empty hash table entries */
        if(arr[i].link != NULL)
        {
            flag = 1;

            main_temp = arr[i].link;

            /* Display every word stored at the current index */
            while(main_temp != NULL)
            {
                sub_temp = main_temp->sub_link;

                /* Print the first file information along with the word */
                if(sub_temp != NULL)
                {
                    printf("%-8d %-20s %-15d %-25s %-12d\n", i, main_temp->word, main_temp->file_count, 
                        sub_temp->file_name, sub_temp->word_count);

                    sub_temp = sub_temp->sub_link;
                }

                /* Print the remaining files containing the same word */
                while(sub_temp != NULL)
                {
                    printf("%-8s %-20s %-15s %-25s %-12d\n", "", "", "",
                           sub_temp->file_name, sub_temp->word_count);

                    sub_temp = sub_temp->sub_link;
                }

                /* Separate each database entry for better readability */
                printf("------------------------------------------------------------------------------------------------------------\n");

                main_temp = main_temp->main_link;
            }
        }
    }

    /* Display a message if the database is empty */
    if(flag == 0)
    {
        printf(RED "\nERROR : Database is Empty.\n" RESET);
    }

    /* Print the closing border of the table */
    printf(BOLD CYAN);
    printf("============================================================================================================\n");
    printf(RESET);
}